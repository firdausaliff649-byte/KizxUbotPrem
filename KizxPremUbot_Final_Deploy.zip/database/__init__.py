from motor.motor_asyncio import AsyncIOMotorClient
import os

# Menggunakan Environment Variable untuk MongoDB Atlas demi keselamatan di GitHub/Vercel
MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://admin:admin@cluster0.abcde.mongodb.net/?retryWrites=true&w=majority")
client = AsyncIOMotorClient(MONGO_URL)
db = client["kizx_ubot_db"]

sessions_db = db["sessions"]
blacklist_db = db["blacklist"]
users_db = db["users"]
payments_db = db["payments"]

async def add_ubot(user_id, session_string):
    await sessions_db.update_one({"user_id": user_id}, {"$set": {"session": session_string}}, upsert=True)

async def remove_ubot(user_id):
    await sessions_db.delete_one({"user_id": user_id})

async def get_all_ubots():
    return [doc async for doc in sessions_db.find()]

async def is_banned(user_id):
    return bool(await blacklist_db.find_one({"user_id": user_id}))

async def ban_user(user_id):
    await blacklist_db.update_one({"user_id": user_id}, {"$set": {"banned": True}}, upsert=True)

async def unban_user(user_id):
    await blacklist_db.delete_one({"user_id": user_id})

async def add_user(user_id):
    await users_db.update_one({"user_id": user_id}, {"$set": {"active": True}}, upsert=True)

async def get_all_users():
    return [doc["user_id"] async for doc in users_db.find()]

async def create_payment(user_id, message_id):
    await payments_db.update_one(
        {"user_id": user_id},
        {"$set": {"status": "pending", "msg_id": message_id}},
        upsert=True
    )

async def get_payment(user_id):
    return await payments_db.find_one({"user_id": user_id})

async def update_payment_status(user_id, status):
    await payments_db.update_one({"user_id": user_id}, {"$set": {"status": status}})
